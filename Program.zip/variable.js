// use strict;
var i = 10;
var j = 10.2;
var str = " Java Script";
// document.write("\n i= ", i);
// document.write("<br>");
// document.write("j= ", j);
// document.write("<br>");
// document.write("str= ", str);
// document.write("<br>");
//  document.write(i + j);
// document.write("<br>");
// document.write(i + str);
document.write("<br>");
// // document.write(3 + 5 + "8");
// // // // document.write("<br>");
// document.write('3' + 5 + "8");
// document.write("<br>");
// document.write('3' * 4);
// document.write("<br>");
document.write("str" * 4);


//*****Null and undefined


//symbol

// const RED = Symbol();
// const ORANGE = Symbol("The color of a sunset!");
// RED === ORANGE // false: every symbol is unique

///whenever you want to have a unique identifier
//



 *** Objects container
difference between array and object
const obj = {};
const student = {
name: 'Sam',
age: 4,
};
const student = { name: 'Sam', age: 4 };


var job = new Object;
var now = new Date();
job.startTime = now.getTime() + 60000;
job.sourceURL = "tv://channel.000100040175";
job.duration = 3600000;
result = CCOM.Scheduler.addJob( "REC", "ONE_TIME", job );


