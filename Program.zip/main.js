/* this is a CSS comment...
which can span multiple lines. */

console.log("echo"); // back in JavaScript...
document.write("hello this is from main js \n");
/* ...so both inline and block comments
are supported. */
