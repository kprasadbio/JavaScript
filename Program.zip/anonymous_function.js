var anonymousFunc = function (msg) {
	alert("The message passed as variable is "+msg);
};
anonymousFunc("Hello");