// var arr1 = [1, 2, 3]; // array of numbers
// const arr2 = ["one", 2, "three"]; // nonhomogeneous array
// const arr3 = [[1, 2, 3], ["one", 2, "three"]]; // array containing arrays
// document.write("<br>");

// document.write(arr1[0]);
// document.write("<br>");

// document.write(arr2[0]);
// document.write("<br>");

// document.write(arr3[0][0]);
// document.write("<br>");

// //Array functions
// length
// document.write("length of array is : ", arr1.length);
// document.write("<br>");
// document.write("length of array is : ", arr3[1].length);
// document.write("<br>");
// document.write(arr3[1].length);

var arr5 = [1, 2, 3];
arr5.push("6"); // new length of the array
document.write(arr5);
// arr5.pop();// return elemement
// document.write("<br>");
// document.write(arr5);
 // returns "e"; arr is now ["b", "c", "d"]
// document.write("<br>");
arr5.unshift("a");// new length of the array
document.write(arr5);
//  // returns 4; arr is now ["a", "b", "c", "d"]
// arr5.shift();//return elemement
// document.write("<br>");
// document.write(arr5);
// var arr = [1, 2, 3];
// arr.concat(4, 5, 6);
// var arrs = arr.concat(4, 5, 6);
// document.write("<br>");
// document.write(arr);
// document.write("<br>");
// document.write(arrs);

// //**** slicing**//
// const slice_arr = [1, 2, 3, 4, 5];
// slice_arr.slice(3); // returns [4, 5]; arr unmodified
// document.write("<br>");
// document.write(arr);
// slice_arr.slice(2, 4);
// document.write("<br>");
// document.write(arr); // returns [3, 4]; arr unmodified
// slice_arr.slice(-2); // returns [4, 5]; arr unmodified
// document.write("<br>");
// document.write(arr);
// slice_arr.slice(1, -2); // returns [2, 3]; arr unmodified
// document.write("<br>");
// document.write(arr);
// slice_arr.slice(-2, -1); // returns [4]; arr unmodified

// ////Reversing array
// const rev_arr = [1, 2, 3, 4, 5];
// rev_arr.reverse();
// document.write("<br>");
// document.write(rev_arr);
